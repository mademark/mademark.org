MADE MARK — ASSET PACK
mademark.org

Contents
--------
svg/
  mm-icon.svg                          System icon ([m])
  mm-icon-human-made.svg               Human Made mark
  mm-icon-human-designed-ai-made.svg   Human Designed, AI Made mark
  mm-icon-ai-made.svg                  AI Made mark
  mm-logo-dark.svg                     Logo for light backgrounds
  mm-logo-white.svg                    Logo for dark backgrounds

png/
  icons/                               Each mark at 16, 32, 64, 128, 256, 512 px
  logo/                                Logo at 120, 240, 480, 960 px wide,
                                       dark and white variants

License
-------
The mark icons are licensed CC BY-ND 4.0
(https://creativecommons.org/licenses/by-nd/4.0/).

You are free to use them unmodified to identify Made Mark authorship on
content. Do not modify, recolor, or repurpose them outside this context.
Credit: Made Mark, mademark.org.

"Made Mark" and the [m] wordmark are trademarks of Daniel Richard Skrok.
You do not need permission to use Made Mark on your content. You may not
use the name or logo to represent a competing or derivative specification.

The Made Mark specification itself is CC0 (public domain):
https://mademark.org

Usage
-----
Which mark applies to your work: https://mademark.org/marks/
Embed snippets and schemas:      https://mademark.org/implement/
Generate a label:                https://mademark.org/generate/

Questions: hello@mademark.org
